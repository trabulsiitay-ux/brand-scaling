import { useState, useEffect, useRef } from "react";

const GOLD = "#C9A84C";
const NAVY = "#0A1628";
const LIGHT_GOLD = "#E8C96A";
const WHITE = "#F8F6F0";
const DARK_NAVY = "#060D1A";

const fadeInUp = `
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(40px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
@keyframes shimmer {
  0% { background-position: -200% center; }
  100% { background-position: 200% center; }
}
@keyframes borderGlow {
  0%, 100% { box-shadow: 0 0 20px rgba(201,168,76,0.2); }
  50% { box-shadow: 0 0 40px rgba(201,168,76,0.5); }
}
`;

const stats = [
  { value: "47+", label: "עורכי דין פעילים" },
  { value: "₪2.8M", label: "בעסקאות שנסגרו" },
  { value: "94%", label: "שיעור המרה של לידים" },
  { value: "21", label: "ימים לתוצאות ראשונות" },
];

const problems = [
  "לידים זולים שמבזבזים את הזמן שלך",
  "לקוחות שלא יכולים להרשות עסקאות גדולות",
  "סוכנויות שלא מבינות את עולם הנדל\"ן הפרימיום",
  "תקציב פרסום שנשרף בלי תוצאות",
];

const solutions = [
  { icon: "◈", title: "מודעות Meta פרימיום", desc: "קמפיינים מדויקים שמגיעים רק לרוכשי נדל\"ן בעלי הון עצמי גבוה" },
  { icon: "◉", title: "דפי נחיתה מותאמים", desc: "עיצוב יוקרתי שמסנן לידים זולים ומשאיר רק רציניים" },
  { icon: "◆", title: "מערכת המרה מלאה", desc: "פאנל אוטומטי שמסנן, מדרג ומעביר לך רק לידים חמים" },
  { icon: "◇", title: "ניתוח ואופטימיזציה", desc: "דוחות שבועיים ושיפור מתמיד על בסיס נתונים אמיתיים" },
];

const testimonials = [
  {
    name: "עו\"ד רון מזרחי",
    role: "מומחה נדל\"ן, תל אביב",
    text: "תוך 3 שבועות קיבלתי 12 לידים — כולם עם תקציב מעל 5 מיליון ש\"ח. לא ראיתי דבר כזה קודם.",
    rating: 5,
  },
  {
    name: "עו\"ד שרה כהן",
    role: "בוטיק משפטי, הרצליה פיתוח",
    text: "הפסקתי לבזבז זמן על פגישות עם לקוחות לא מתאימים. Brand Scaling שינתה את המשחק.",
    rating: 5,
  },
  {
    name: "עו\"ד דניאל לוי",
    role: "עסקאות נדל\"ן יוקרה, רמת השרון",
    text: "ROI של 680% בחודש הראשון. המערכת עובדת כשאני ישן.",
    rating: 5,
  },
];

function StarRating({ count }) {
  return (
    <div style={{ display: "flex", gap: 4 }}>
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} style={{ color: GOLD, fontSize: 16 }}>★</span>
      ))}
    </div>
  );
}

function AnimatedSection({ children, delay = 0, style = {} }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(36px)",
        transition: `opacity 0.7s ease ${delay}s, transform 0.7s ease ${delay}s`,
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export default function App() {
  const [formData, setFormData] = useState({ name: "", phone: "", firm: "" });
  const [submitted, setSubmitted] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleSubmit = () => {
    if (formData.name && formData.phone) setSubmitted(true);
  };

  return (
    <div dir="rtl" style={{ fontFamily: "'Frank Ruhl Libre', 'David Libre', Georgia, serif", background: DARK_NAVY, color: WHITE, minHeight: "100vh", overflowX: "hidden" }}>
      <style>{`
        ${fadeInUp}
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        .gold-shimmer {
          background: linear-gradient(90deg, ${GOLD} 0%, ${LIGHT_GOLD} 40%, #fff8e7 50%, ${LIGHT_GOLD} 60%, ${GOLD} 100%);
          background-size: 200% auto;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: shimmer 4s linear infinite;
        }
        .cta-btn {
          background: linear-gradient(135deg, ${GOLD}, ${LIGHT_GOLD}, ${GOLD});
          color: ${DARK_NAVY};
          border: none;
          padding: 18px 48px;
          font-size: 18px;
          font-family: 'Heebo', sans-serif;
          font-weight: 700;
          cursor: pointer;
          letter-spacing: 1px;
          transition: transform 0.2s, box-shadow 0.2s;
          clip-path: polygon(12px 0%, 100% 0%, calc(100% - 12px) 100%, 0% 100%);
        }
        .cta-btn:hover {
          transform: translateY(-3px);
          box-shadow: 0 12px 40px rgba(201,168,76,0.5);
        }
        .nav-link {
          color: rgba(248,246,240,0.7);
          text-decoration: none;
          font-family: 'Heebo', sans-serif;
          font-size: 15px;
          transition: color 0.2s;
          font-weight: 400;
        }
        .nav-link:hover { color: ${GOLD}; }
        .card-hover {
          transition: transform 0.3s, box-shadow 0.3s, border-color 0.3s;
        }
        .card-hover:hover {
          transform: translateY(-6px);
          box-shadow: 0 20px 60px rgba(0,0,0,0.4), 0 0 30px rgba(201,168,76,0.15);
          border-color: rgba(201,168,76,0.5) !important;
        }
        .form-input {
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(201,168,76,0.3);
          color: ${WHITE};
          padding: 14px 18px;
          font-size: 15px;
          font-family: 'Heebo', sans-serif;
          width: 100%;
          outline: none;
          transition: border-color 0.2s, background 0.2s;
          border-radius: 2px;
        }
        .form-input:focus {
          border-color: ${GOLD};
          background: rgba(201,168,76,0.05);
        }
        .form-input::placeholder { color: rgba(248,246,240,0.35); }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${DARK_NAVY}; }
        ::-webkit-scrollbar-thumb { background: ${GOLD}; border-radius: 3px; }
      `}</style>

      {/* Navbar */}
      <nav style={{
        position: "fixed", top: 0, width: "100%", zIndex: 100,
        background: scrolled ? "rgba(6,13,26,0.96)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? `1px solid rgba(201,168,76,0.2)` : "none",
        transition: "all 0.4s",
        padding: "0 5%",
      }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center", height: 72 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, background: `linear-gradient(135deg, ${GOLD}, ${LIGHT_GOLD})`, clipPath: "polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)" }} />
            <span style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: 20, fontWeight: 700, letterSpacing: 2, color: WHITE }}>BRAND <span className="gold-shimmer">SCALING</span></span>
          </div>
          <div style={{ display: "flex", gap: 36 }}>
            <a href="#about" className="nav-link">על השירות</a>
            <a href="#results" className="nav-link">תוצאות</a>
            <a href="#testimonials" className="nav-link">לקוחות</a>
            <a href="#contact" className="nav-link" style={{ color: GOLD }}>צור קשר</a>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section style={{ minHeight: "100vh", display: "flex", alignItems: "center", position: "relative", overflow: "hidden", padding: "120px 5% 80px" }}>
        <div style={{ position: "absolute", inset: 0, background: `radial-gradient(ellipse 80% 60% at 30% 50%, rgba(201,168,76,0.08) 0%, transparent 70%)` }} />
        <div style={{ position: "absolute", top: "10%", left: "5%", width: 1, height: "80%", background: `linear-gradient(to bottom, transparent, ${GOLD}33, transparent)` }} />
        {[20, 40, 60, 80].map(pct => (
          <div key={pct} style={{ position: "absolute", top: 0, left: `${pct}%`, width: 1, height: "100%", background: "rgba(201,168,76,0.04)", pointerEvents: "none" }} />
        ))}

        <div style={{ maxWidth: 1200, margin: "0 auto", width: "100%", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "center" }}>
          <div style={{ animation: "fadeInUp 0.9s ease forwards" }}>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 10, border: `1px solid ${GOLD}44`, padding: "8px 20px", marginBottom: 32, background: "rgba(201,168,76,0.05)" }}>
              <div style={{ width: 6, height: 6, background: GOLD, borderRadius: "50%" }} />
              <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 12, letterSpacing: 3, color: GOLD, textTransform: "uppercase" }}>בלעדי לעורכי דין נדל״ן פרימיום</span>
            </div>
            <h1 style={{ fontSize: "clamp(38px, 4.5vw, 58px)", fontWeight: 900, lineHeight: 1.15, marginBottom: 24, fontFamily: "'Frank Ruhl Libre', serif" }}>
              הפסק לרדוף<br />
              <span className="gold-shimmer">לידים זולים.</span><br />
              התחל לסגור עסקאות.
            </h1>
            <p style={{ fontFamily: "'Heebo', sans-serif", fontSize: 18, lineHeight: 1.8, color: "rgba(248,246,240,0.72)", marginBottom: 48, maxWidth: 480, fontWeight: 300 }}>
              אנחנו בונים מערכת המרה מלאה — מודעות Meta + דפי נחיתה פרימיום — שמסננת לידים זולים ומעבירה לך רק לקוחות עם תקציב גבוה שמוכנים לסגור.
            </p>
            <div style={{ display: "flex", gap: 20, alignItems: "center", flexWrap: "wrap" }}>
              <button className="cta-btn" onClick={() => document.getElementById("contact").scrollIntoView({ behavior: "smooth" })}>
                קבל אסטרטגיה חינם ←
              </button>
              <a href="#results" style={{ fontFamily: "'Heebo', sans-serif", fontSize: 15, color: "rgba(248,246,240,0.6)", textDecoration: "none", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ color: GOLD }}>▶</span> ראה תוצאות אמיתיות
              </a>
            </div>
            <div style={{ marginTop: 56, display: "flex", gap: 40 }}>
              {[{ n: "47+", l: "עורכי דין" }, { n: "94%", l: "שיעור המרה" }, { n: "₪2.8M+", l: "עסקאות" }].map((s, i) => (
                <div key={i} style={{ animation: `fadeInUp 0.9s ease ${0.2 + i * 0.1}s both` }}>
                  <div style={{ fontSize: 28, fontWeight: 900, color: GOLD, fontFamily: "'Frank Ruhl Libre', serif" }}>{s.n}</div>
                  <div style={{ fontSize: 13, color: "rgba(248,246,240,0.5)", fontFamily: "'Heebo', sans-serif", marginTop: 4 }}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ animation: "fadeIn 1.2s ease forwards", animationDelay: "0.3s", opacity: 0 }}>
            <div style={{ background: `linear-gradient(135deg, rgba(201,168,76,0.08) 0%, rgba(10,22,40,0.8) 100%)`, border: `1px solid rgba(201,168,76,0.25)`, borderRadius: 4, padding: 40, position: "relative", animation: "borderGlow 4s ease infinite" }}>
              <div style={{ position: "absolute", top: -1, right: 40, width: 80, height: 2, background: `linear-gradient(to right, transparent, ${GOLD})` }} />
              <div style={{ textAlign: "center", marginBottom: 32 }}>
                <div style={{ fontSize: 13, fontFamily: "'Heebo', sans-serif", letterSpacing: 3, color: GOLD, textTransform: "uppercase", marginBottom: 16 }}>ביצועי הקמפיין — חודש אחרון</div>
                <div style={{ fontSize: 56, fontWeight: 900, fontFamily: "'Frank Ruhl Libre', serif" }} className="gold-shimmer">₪4.2M</div>
                <div style={{ fontSize: 14, color: "rgba(248,246,240,0.5)", fontFamily: "'Heebo', sans-serif", marginTop: 8 }}>שווי עסקאות שנסגרו ע"י לקוחותינו</div>
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                {[
                  { label: "לידים שנוצרו", value: "84" },
                  { label: "לידים מוסמכים", value: "79" },
                  { label: "פגישות שנקבעו", value: "31" },
                  { label: "עסקאות שנסגרו", value: "18" },
                ].map((item, i) => (
                  <div key={i} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(201,168,76,0.12)", padding: "16px 20px", borderRadius: 2 }}>
                    <div style={{ fontSize: 24, fontWeight: 700, fontFamily: "'Frank Ruhl Libre', serif", color: WHITE }}>{item.value}</div>
                    <div style={{ fontSize: 12, color: "rgba(248,246,240,0.45)", fontFamily: "'Heebo', sans-serif", marginTop: 4 }}>{item.label}</div>
                    <div style={{ fontSize: 12, color: "#4ade80", marginTop: 6 }}>↑ +{[23, 18, 31, 27][i]}%</div>
                  </div>
                ))}
              </div>
              <div style={{ marginTop: 24, padding: "14px 20px", background: `rgba(201,168,76,0.08)`, border: `1px solid ${GOLD}33`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: "rgba(248,246,240,0.6)" }}>עלות לליד מוסמך</span>
                <span style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: 20, fontWeight: 700, color: GOLD }}>₪187 בלבד</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section id="about" style={{ padding: "100px 5%", position: "relative" }}>
        <div style={{ position: "absolute", inset: 0, background: `linear-gradient(180deg, transparent 0%, rgba(201,168,76,0.03) 50%, transparent 100%)` }} />
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <AnimatedSection>
            <div style={{ textAlign: "center", marginBottom: 72 }}>
              <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 12, letterSpacing: 4, color: GOLD, textTransform: "uppercase" }}>הבעיה שכולם מכירים</span>
              <h2 style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: "clamp(30px, 3.5vw, 46px)", fontWeight: 800, marginTop: 16, lineHeight: 1.3 }}>
                למה סוכנויות שיווק רגילות<br /><span className="gold-shimmer">פוגעות בעסק שלך</span>
              </h2>
            </div>
          </AnimatedSection>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 24 }}>
            {problems.map((p, i) => (
              <AnimatedSection key={i} delay={i * 0.1}>
                <div style={{ display: "flex", gap: 20, alignItems: "flex-start", padding: 28, border: "1px solid rgba(255,80,80,0.15)", background: "rgba(255,50,50,0.03)", borderRadius: 2 }}>
                  <div style={{ width: 32, height: 32, background: "rgba(255,80,80,0.1)", border: "1px solid rgba(255,80,80,0.3)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, borderRadius: 2 }}>
                    <span style={{ color: "#ff6b6b", fontSize: 16 }}>✕</span>
                  </div>
                  <p style={{ fontFamily: "'Heebo', sans-serif", fontSize: 16, lineHeight: 1.6, color: "rgba(248,246,240,0.75)", fontWeight: 400 }}>{p}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Solution Section */}
      <section style={{ padding: "100px 5%", background: `linear-gradient(180deg, transparent 0%, rgba(201,168,76,0.04) 50%, transparent 100%)` }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <AnimatedSection>
            <div style={{ textAlign: "center", marginBottom: 72 }}>
              <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 12, letterSpacing: 4, color: GOLD, textTransform: "uppercase" }}>הפתרון שלנו</span>
              <h2 style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: "clamp(30px, 3.5vw, 46px)", fontWeight: 800, marginTop: 16 }}>
                מערכת המרה <span className="gold-shimmer">מלאה ומדויקת</span>
              </h2>
            </div>
          </AnimatedSection>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 28 }}>
            {solutions.map((s, i) => (
              <AnimatedSection key={i} delay={i * 0.12}>
                <div className="card-hover" style={{ padding: 36, border: "1px solid rgba(201,168,76,0.18)", background: "rgba(10,22,40,0.6)", borderRadius: 2, height: "100%" }}>
                  <div style={{ fontSize: 28, color: GOLD, marginBottom: 20 }}>{s.icon}</div>
                  <h3 style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: 22, fontWeight: 700, marginBottom: 14, color: WHITE }}>{s.title}</h3>
                  <p style={{ fontFamily: "'Heebo', sans-serif", fontSize: 15, lineHeight: 1.75, color: "rgba(248,246,240,0.65)", fontWeight: 300 }}>{s.desc}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section id="results" style={{ padding: "80px 5%", borderTop: "1px solid rgba(201,168,76,0.12)", borderBottom: "1px solid rgba(201,168,76,0.12)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 40 }}>
          {stats.map((s, i) => (
            <AnimatedSection key={i} delay={i * 0.1}>
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: "clamp(36px, 4vw, 52px)", fontWeight: 900, fontFamily: "'Frank Ruhl Libre', serif" }} className="gold-shimmer">{s.value}</div>
                <div style={{ fontFamily: "'Heebo', sans-serif", fontSize: 14, color: "rgba(248,246,240,0.5)", marginTop: 10, letterSpacing: 1 }}>{s.label}</div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" style={{ padding: "100px 5%" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
          <AnimatedSection>
            <div style={{ textAlign: "center", marginBottom: 72 }}>
              <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 12, letterSpacing: 4, color: GOLD, textTransform: "uppercase" }}>מה אומרים הלקוחות</span>
              <h2 style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: "clamp(30px, 3.5vw, 46px)", fontWeight: 800, marginTop: 16 }}>
                עורכי דין שכבר <span className="gold-shimmer">מרוויחים יותר</span>
              </h2>
            </div>
          </AnimatedSection>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 28 }}>
            {testimonials.map((t, i) => (
              <AnimatedSection key={i} delay={i * 0.12}>
                <div className="card-hover" style={{ padding: 36, border: "1px solid rgba(201,168,76,0.2)", background: "rgba(10,22,40,0.7)", borderRadius: 2, position: "relative" }}>
                  <div style={{ position: "absolute", top: 24, left: 28, fontSize: 48, color: `${GOLD}22`, fontFamily: "Georgia", lineHeight: 1 }}>"</div>
                  <StarRating count={t.rating} />
                  <p style={{ fontFamily: "'Heebo', sans-serif", fontSize: 15, lineHeight: 1.8, color: "rgba(248,246,240,0.78)", marginTop: 20, marginBottom: 28, fontWeight: 300 }}>"{t.text}"</p>
                  <div style={{ borderTop: "1px solid rgba(201,168,76,0.15)", paddingTop: 20 }}>
                    <div style={{ fontFamily: "'Frank Ruhl Libre', serif", fontWeight: 700, fontSize: 16, color: WHITE }}>{t.name}</div>
                    <div style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: GOLD, marginTop: 4 }}>{t.role}</div>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section id="contact" style={{ padding: "100px 5%", background: `linear-gradient(180deg, transparent 0%, rgba(201,168,76,0.05) 50%, transparent 100%)` }}>
        <div style={{ maxWidth: 640, margin: "0 auto" }}>
          <AnimatedSection>
            <div style={{ textAlign: "center", marginBottom: 56 }}>
              <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 12, letterSpacing: 4, color: GOLD, textTransform: "uppercase" }}>מוכן לצמוח?</span>
              <h2 style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: "clamp(28px, 3.5vw, 42px)", fontWeight: 800, marginTop: 16, marginBottom: 16 }}>
                קבל <span className="gold-shimmer">אסטרטגיה אישית</span> בחינם
              </h2>
              <p style={{ fontFamily: "'Heebo', sans-serif", fontSize: 16, color: "rgba(248,246,240,0.55)", fontWeight: 300 }}>שיחת ייעוץ של 30 דקות — ללא עלות, ללא התחייבות</p>
            </div>
          </AnimatedSection>
          <AnimatedSection delay={0.15}>
            {!submitted ? (
              <div style={{ border: "1px solid rgba(201,168,76,0.25)", background: "rgba(10,22,40,0.8)", padding: 48, borderRadius: 2, position: "relative" }}>
                <div style={{ position: "absolute", top: -1, right: 60, width: 100, height: 2, background: `linear-gradient(to right, transparent, ${GOLD})` }} />
                <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
                  <div>
                    <label style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: GOLD, display: "block", marginBottom: 8, letterSpacing: 1 }}>שם מלא *</label>
                    <input className="form-input" placeholder="עו״ד ישראל ישראלי" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} />
                  </div>
                  <div>
                    <label style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: GOLD, display: "block", marginBottom: 8, letterSpacing: 1 }}>טלפון *</label>
                    <input className="form-input" placeholder="050-000-0000" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} />
                  </div>
                  <div>
                    <label style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: GOLD, display: "block", marginBottom: 8, letterSpacing: 1 }}>שם משרד</label>
                    <input className="form-input" placeholder="משרד עורכי דין..." value={formData.firm} onChange={e => setFormData({ ...formData, firm: e.target.value })} />
                  </div>
                  <button className="cta-btn" onClick={handleSubmit} style={{ marginTop: 12, width: "100%", clipPath: "none", borderRadius: 2 }}>
                    שלח ← קבל שיחת ייעוץ חינם
                  </button>
                  <p style={{ textAlign: "center", fontFamily: "'Heebo', sans-serif", fontSize: 12, color: "rgba(248,246,240,0.35)", marginTop: 8 }}>
                    🔒 הפרטים שמורים אצלנו בסודיות מלאה
                  </p>
                </div>
              </div>
            ) : (
              <div style={{ border: `1px solid ${GOLD}44`, background: "rgba(201,168,76,0.06)", padding: 56, borderRadius: 2, textAlign: "center", animation: "fadeInUp 0.6s ease forwards" }}>
                <div style={{ fontSize: 48, marginBottom: 24 }}>✦</div>
                <h3 style={{ fontFamily: "'Frank Ruhl Libre', serif", fontSize: 28, fontWeight: 800, color: GOLD, marginBottom: 16 }}>קיבלנו!</h3>
                <p style={{ fontFamily: "'Heebo', sans-serif", fontSize: 16, color: "rgba(248,246,240,0.7)", lineHeight: 1.7, fontWeight: 300 }}>ניצור איתך קשר בתוך 24 שעות לתיאום שיחת האסטרטגיה שלך.</p>
              </div>
            )}
          </AnimatedSection>
        </div>
      </section>

      {/* Footer */}
      <footer style={{ padding: "40px 5%", borderTop: "1px solid rgba(201,168,76,0.12)" }}>
        <div style={{ maxWidth: 1200, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontFamily: "'Frank Ruhl Libre', serif", fontWeight: 700, letterSpacing: 2, color: WHITE, fontSize: 16 }}>BRAND <span style={{ color: GOLD }}>SCALING</span></span>
          <span style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: "rgba(248,246,240,0.3)" }}>© 2025 Brand Scaling. כל הזכויות שמורות.</span>
          <a href="mailto:info@brandscaling.co.il" style={{ fontFamily: "'Heebo', sans-serif", fontSize: 13, color: GOLD, textDecoration: "none" }}>info@brandscaling.co.il</a>
        </div>
      </footer>
    </div>
  );
}
